import{N as p,O as t}from"./CpxVo7Xb.js";import{B as c}from"./C1oSKhUs.js";function f(r,s,...a){var e=new c(r);p(()=>{const n=s()??null;e.ensure(n,n&&(o=>n(o,...a)))},t)}export{f as s};
