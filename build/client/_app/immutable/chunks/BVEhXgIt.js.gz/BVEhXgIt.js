function s(n,l,r){var t=n==null?"":""+n;return l&&(t=t?t+" "+l:l),t===""?null:t}function e(n,l){return n==null?null:String(n)}export{e as a,s as t};
